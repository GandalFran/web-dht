# DHT's node server

## How to deploy

### install
To install depencies run `npm install`

### configure
To configure, create a file called `config.json` in the root directory, and copy the contents of `default-config.json`.
If the file `config.json` is not found, the `default-config.json` will be used as configuration file.

### run
To run the server first compile the project with `npm run build` and then start the server with `npm run start`
